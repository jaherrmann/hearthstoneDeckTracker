CREATE TRIGGER stats_after_insert
AFTER INSERT ON decklist
FOR EACH ROW
  BEGIN insert into stats (wins, losses, win_percentage, deck_id) values (0, 0, 0, new.id); END;
